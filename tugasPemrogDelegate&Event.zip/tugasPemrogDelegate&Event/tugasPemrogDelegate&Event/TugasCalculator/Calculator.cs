﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// NAMA : FIRRESA ALIF NURRAHMAN NIM : 21.11.4104 KELAS : 21 IF 04

namespace TugasCalculator
{
    public class Calculator
    {
        public int NilaiA { get; set; }
        public int NilaiB { get; set; }
        public string Hasil { get; set; }

    }
}
